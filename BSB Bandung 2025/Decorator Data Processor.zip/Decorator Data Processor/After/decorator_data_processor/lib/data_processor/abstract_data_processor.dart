import 'package:decorator_data_processor/auth_data.dart';

abstract class AbstractAuthDataProcessor {
  final AuthData authData;
  final void Function(AuthData authData)? onValid;
  final void Function(List<String> errorMessages)? onInvalid;

  AbstractAuthDataProcessor({
    required this.authData,
    this.onValid,
    this.onInvalid,
  });

  List<String> validate();

  void process() {
    List<String> errorMessage = validate();

    if (errorMessage.isEmpty) {
      onValid?.call(authData);
    } else {
      onInvalid?.call(errorMessage);
    }
  }
}
