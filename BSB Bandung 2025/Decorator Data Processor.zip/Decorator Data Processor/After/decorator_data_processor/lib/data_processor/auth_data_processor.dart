import 'package:decorator_data_processor/data_processor/abstract_data_processor.dart';

class AuthDataProcessor extends AbstractAuthDataProcessor {
  AuthDataProcessor({required super.authData, super.onValid, super.onInvalid});

  @override
  List<String> validate() => const [];
}
