import 'package:decorator_data_processor/validator/validator.dart';

class PasswordHasCapitalLetter extends Validator {
  PasswordHasCapitalLetter(super.dataProcessor);

  @override
  List<String> validate() {
    if (!authData.password.contains(RegExp(r'[A-Z]'))) {
      return [
        'Password must contain at least one capital letter',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
