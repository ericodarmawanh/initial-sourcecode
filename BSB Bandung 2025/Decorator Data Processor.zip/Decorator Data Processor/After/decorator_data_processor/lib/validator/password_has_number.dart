import 'package:decorator_data_processor/validator/validator.dart';

class PasswordHasNumber extends Validator {
  PasswordHasNumber(super.dataProcessor);

  @override
  List<String> validate() {
    if (!authData.password.contains(RegExp(r'[0-9]'))) {
      return [
        'Password must contain at least one number',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
