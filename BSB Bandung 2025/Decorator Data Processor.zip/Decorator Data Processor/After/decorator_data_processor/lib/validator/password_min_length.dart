import 'package:decorator_data_processor/validator/validator.dart';

class PasswordMinLength extends Validator {
  final int minLength;

  PasswordMinLength(super.dataProcessor, {this.minLength = 6});

  @override
  List<String> validate() {
    if (authData.password.length < minLength) {
      return [
        'Password must be at least $minLength characters long',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
