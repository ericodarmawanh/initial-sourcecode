import 'package:decorator_data_processor/data_processor/abstract_data_processor.dart';

abstract class Validator extends AbstractAuthDataProcessor {
  final AbstractAuthDataProcessor dataProcessor;

  Validator(this.dataProcessor)
    : super(
        authData: dataProcessor.authData,
        onValid: dataProcessor.onValid,
        onInvalid: dataProcessor.onInvalid,
      );
}
