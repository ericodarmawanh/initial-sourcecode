class AuthData {
  final String username;
  final String password;

  AuthData({required this.username, required this.password});
}
