import 'package:decorator_data_processor/auth_data.dart';

class AuthDataProcessor {
  final AuthData authData;
  final void Function(AuthData authData)? onValid;
  final void Function(List<String> errorMessages)? onInvalid;

  AuthDataProcessor({required this.authData, this.onInvalid, this.onValid});

  List<String> validate() {
    // List of error messages
    List<String> errorMessage = [];

    // Password must be at least 6 characters long
    if (authData.password.length < 6) {
      errorMessage.add('Password must be at least 6 characters long');
    }

    // Password must contain at least one capital letter
    if (!authData.password.contains(RegExp(r'[A-Z]'))) {
      errorMessage.add('Password must contain at least one capital letter');
    }

    return errorMessage;
  }

  void process() {
    List<String> errorMessage = validate();

    if (errorMessage.isEmpty) {
      onValid?.call(authData);
    } else {
      onInvalid?.call(errorMessage);
    }
  }
}
