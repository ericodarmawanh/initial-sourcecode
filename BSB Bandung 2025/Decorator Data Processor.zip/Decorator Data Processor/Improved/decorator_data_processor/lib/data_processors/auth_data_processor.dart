import '../auth_data.dart';
import 'data_processor.dart';

class AuthDataProcessor extends DataProcessor<AuthData> {
  AuthDataProcessor({required super.data, super.onValid, super.onInvalid});

  @override
  List<String> validate() => const [];
}
