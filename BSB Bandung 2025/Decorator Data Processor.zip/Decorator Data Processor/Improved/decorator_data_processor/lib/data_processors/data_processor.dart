abstract class DataProcessor<T> {
  final T data;
  final void Function(T data)? onValid;
  final void Function(List<String> errorMessages)? onInvalid;

  DataProcessor({
    required this.data,
    required this.onValid,
    required this.onInvalid,
  });

  List<String> validate();

  void process() {
    List<String> errorMessage = validate();

    if (errorMessage.isEmpty) {
      onValid?.call(data);
    } else {
      onInvalid?.call(errorMessage);
    }
  }
}
