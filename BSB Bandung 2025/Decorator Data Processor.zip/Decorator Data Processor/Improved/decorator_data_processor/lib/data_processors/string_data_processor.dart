import 'data_processor.dart';

class StringDataProcessor extends DataProcessor<String> {
  StringDataProcessor({required super.data, super.onValid, super.onInvalid});

  @override
  List<String> validate() => const [];
}
