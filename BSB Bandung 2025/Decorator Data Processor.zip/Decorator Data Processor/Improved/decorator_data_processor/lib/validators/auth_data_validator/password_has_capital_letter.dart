import '../../auth_data.dart';
import '../../data_processors/string_data_processor.dart';
import '../string_validator/string_contains_capital_letter.dart';
import '../validator.dart';

class PasswordHasCapitalLetter extends Validator<AuthData> {
  PasswordHasCapitalLetter(super.dataProcessor);

  @override
  List<String> validate() {
    List<String> result = dataProcessor.validate();

    StringContainsCapitalLetter(
      StringDataProcessor(
        data: data.password,
        onInvalid:
            (_) =>
                result = [
                  'Password must contain at least one capital letter',
                  ...result,
                ],
      ),
    ).process();

    return result;
  }
}
