import '../../auth_data.dart';
import '../../data_processors/string_data_processor.dart';
import '../string_validator/string_contains_number.dart';
import '../validator.dart';

class PasswordHasNumber extends Validator<AuthData> {
  PasswordHasNumber(super.dataProcessor);

  @override
  List<String> validate() {
    List<String> result = dataProcessor.validate();

    StringContainsNumber(
      StringDataProcessor(
        data: data.password,
        onInvalid:
            (_) =>
                result = [
                  'Password must contain at least one number',
                  ...result,
                ],
      ),
    ).process();

    return result;
  }
}
