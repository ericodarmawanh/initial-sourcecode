import '../../auth_data.dart';
import '../../data_processors/string_data_processor.dart';
import '../string_validator/string_min_length.dart';
import '../validator.dart';

class PasswordMinLength extends Validator<AuthData> {
  final int minLength;

  PasswordMinLength(super.dataProcessor, {this.minLength = 6});

  @override
  List<String> validate() {
    List<String> result = dataProcessor.validate();

    StringMinLength(
      StringDataProcessor(
        data: data.password,
        onInvalid:
            (_) =>
                result = [
                  'Password must be at least $minLength characters long',
                  ...result,
                ],
      ),
      minLength: minLength,
    ).process();

    return result;
  }
}
