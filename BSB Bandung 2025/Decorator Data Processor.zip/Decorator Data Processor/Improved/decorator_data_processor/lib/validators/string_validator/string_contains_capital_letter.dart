import '../validator.dart';

class StringContainsCapitalLetter extends Validator<String> {
  StringContainsCapitalLetter(super.dataProcessor);

  @override
  List<String> validate() {
    if (!data.contains(RegExp(r'[A-Z]'))) {
      return [
        'String must contain at least one capital letter',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
