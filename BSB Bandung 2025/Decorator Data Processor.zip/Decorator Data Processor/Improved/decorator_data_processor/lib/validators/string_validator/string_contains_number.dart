import '../validator.dart';

class StringContainsNumber extends Validator<String> {
  StringContainsNumber(super.dataProcessor);

  @override
  List<String> validate() {
    if (!data.contains(RegExp(r'[0-9]'))) {
      return [
        'String must contain at least one number',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
