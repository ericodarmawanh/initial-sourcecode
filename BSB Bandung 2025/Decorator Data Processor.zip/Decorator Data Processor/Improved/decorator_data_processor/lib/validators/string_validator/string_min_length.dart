import '../validator.dart';

class StringMinLength extends Validator<String> {
  final int minLength;

  StringMinLength(super.dataProcessor, {required this.minLength});

  @override
  List<String> validate() {
    if (data.length < minLength) {
      return [
        'String must be at least $minLength characters long',
        ...dataProcessor.validate(),
      ];
    }

    return dataProcessor.validate();
  }
}
