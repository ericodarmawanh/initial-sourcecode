import '../data_processors/data_processor.dart';

abstract class Validator<T> extends DataProcessor<T> {
  final DataProcessor<T> dataProcessor;

  Validator(this.dataProcessor)
    : super(
        data: dataProcessor.data,
        onValid: dataProcessor.onValid,
        onInvalid: dataProcessor.onInvalid,
      );
}
