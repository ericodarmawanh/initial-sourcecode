import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '/pages/login_page.dart';
import '/pages/main_page.dart';
import 'entities/user.dart' as entities;

const supabaseUrl = 'your supabase url here';
const supabaseKey = 'your supabase key here';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);

  runApp(MainApp());
}

class MainApp extends StatelessWidget {
  final supabase = Supabase.instance.client;

  MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light(useMaterial3: true),
      home: StreamBuilder(
        stream: supabase.auth.onAuthStateChange.map((event) {
          if (event.event == AuthChangeEvent.signedIn) {
            var currentUser = supabase.auth.currentUser;
            return entities.User(
              id: currentUser!.id,
              email: currentUser.email!,
            );
          } else {
            return null;
          }
        }),
        builder: (context, snapshot) =>
            snapshot.hasData && snapshot.data != null
                ? MainPage(
                    user: snapshot.data!,
                  )
                : LoginPage(),
      ),
    );
  }
}
