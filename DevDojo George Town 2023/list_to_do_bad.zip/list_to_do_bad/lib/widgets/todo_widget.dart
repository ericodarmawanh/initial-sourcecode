import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:list_to_do/entities/todo.dart';

class TodoWidget extends StatelessWidget {
  final Todo todo;
  final double width;
  final void Function(bool)? onChanged;

  const TodoWidget(
      {super.key, required this.width, required this.todo, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Row(
        children: [
          Checkbox(
            value: todo.completed,
            onChanged: (value) {
              if (onChanged != null) {
                onChanged!(value ?? false);
              }
            },
          ),
          Expanded(
            child: Text(todo.description,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w500,
                  decoration: todo.completed
                      ? TextDecoration.lineThrough
                      : TextDecoration.none,
                )),
          ),
        ],
      ),
    );
  }
}
