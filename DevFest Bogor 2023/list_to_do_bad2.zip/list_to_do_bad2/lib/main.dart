import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'pages/login_page.dart';
import 'pages/main_page.dart';
import 'supabase/supabase_authentication.dart';

const supabaseUrl = 'your supabase url here';
const supabaseKey = 'your supabase key here';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light(useMaterial3: true),
      home: StreamBuilder(
        stream: SupabaseAuthentication().onUserChanged(),
        builder: (context, snapshot) =>
            snapshot.hasData && snapshot.data != null
                ? MainPage(
                    user: snapshot.data!,
                  )
                : LoginPage(),
      ),
    );
  }
}
