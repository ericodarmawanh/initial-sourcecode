import 'dart:async';

import '../entities/user.dart';
import 'mock_todo_repository.dart';

class MockAuthentication {
  static final StreamController<User?> _userStream = StreamController();

  Future<void> login({required String email, required String password}) async {
    _userStream.sink.add(User(id: '1', email: email));
  }

  Future<void> logout() async {
    _userStream.sink.add(null);
    MockTodoRepository.resetStream();
  }

  Stream<User?> onUserChanged() => _userStream.stream;

  Future<User> register({required String email, required String password}) {
    // TODO: implement register
    throw UnimplementedError();
  }
}
