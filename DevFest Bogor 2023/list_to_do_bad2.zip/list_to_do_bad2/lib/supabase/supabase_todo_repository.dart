import 'package:supabase_flutter/supabase_flutter.dart';

import '../../entities/todo.dart';

class SupabaseTodoRepository {
  final SupabaseClient supabase;

  SupabaseTodoRepository({SupabaseClient? supabase})
      : supabase = supabase ?? Supabase.instance.client;

  Future<void> add(Todo todo) async => await supabase
      .from('todos')
      .insert(todo.toJson()..removeWhere((key, value) => value == null));

  Stream<List<Todo>> todos(String uid) => supabase
      .from('todos')
      .stream(primaryKey: ['id'])
      .eq('uid', uid)
      .order('id')
      .map((event) => event.map((json) => Todo.fromJson(json)).toList());

  Future<void> update(Todo todo) async {
    await supabase.from('todos').update(todo.toJson()).eq('id', todo.id);
  }
}
