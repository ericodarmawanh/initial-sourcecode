import 'package:flutter_test/flutter_test.dart';
import 'package:list_to_do/supabase/supabase_authentication.dart';
import 'package:supabase/supabase.dart';

const supabaseUrl = 'https://mkgqhpcnlfivrvhnwuqi.supabase.co';
const supabaseKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1rZ3FocGNubGZpdnJ2aG53dXFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTYyNDAxNjcsImV4cCI6MjAxMTgxNjE2N30.iji39oNFnhgPh3h2_Yx4LyE-WSuT80AHZt9yIxiWw0k';

void main() async {
  final supabase = SupabaseClient(supabaseUrl, supabaseKey);

  group('SupabaseAuthentication Test:', () {
    test('Login', () async {
      User? user = supabase.auth.currentUser;
      expect(user, isNull);

      await SupabaseAuthentication(supabase: supabase)
          .login(password: '123456', email: 'erico.dh@blackpink.com');

      user = supabase.auth.currentUser;

      expect(user, isNotNull);
      expect(user?.email, equals('erico.dh@blackpink.com'));
    });

    test('Logout', () async {
      await SupabaseAuthentication(supabase: supabase).logout();

      User? user = supabase.auth.currentUser;
      expect(user, isNull);
    });
  });
}
