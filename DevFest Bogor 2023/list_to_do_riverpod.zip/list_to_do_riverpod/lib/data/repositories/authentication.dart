import '../../entities/user.dart';

abstract interface class Authentication {
  Future<void> login({required String email, required String password});
  Future<User> register({required String email, required String password});
  Stream<User?> onUserChanged();
  Future<void> logout();
}
