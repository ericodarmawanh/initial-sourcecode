import '../../entities/todo.dart';

abstract interface class TodoRepository {
  Stream<List<Todo>> todos(String uid);
  Future<void> add(Todo todo);
  Future<void> update(Todo todo);
}
