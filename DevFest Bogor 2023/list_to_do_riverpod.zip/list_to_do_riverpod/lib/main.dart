import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'presentation/pages/login_page.dart';
import 'presentation/pages/main_page.dart';
import 'presentation/providers/user_provider.dart';

const supabaseUrl = 'your supabase url here';
const supabaseKey = 'your supabase key here';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);

  runApp(const ProviderScope(child: MainApp()));
}

class MainApp extends ConsumerWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      theme: ThemeData.light(useMaterial3: true),
      home: ref.watch(userProvider).when(
          data: (data) => data != null ? MainPage() : LoginPage(),
          error: (error, stackTrace) => LoginPage(),
          loading: () => LoginPage()),
    );
  }
}
