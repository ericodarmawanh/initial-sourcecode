import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../data/mock/mock_authentication.dart';
import '../../data/repositories/authentication.dart';
import '../../data/supabase/supabase_authentication.dart';

part 'authentication_provider.g.dart';

@riverpod
Authentication authentication(AuthenticationRef ref) =>
    SupabaseAuthentication();
    // MockAuthentication();
