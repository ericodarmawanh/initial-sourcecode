// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'authentication_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authenticationHash() => r'c03867a6efd252600d3d5d2bcbcbc6b2a5b13091';

/// See also [authentication].
@ProviderFor(authentication)
final authenticationProvider = AutoDisposeProvider<Authentication>.internal(
  authentication,
  name: r'authenticationProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authenticationHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AuthenticationRef = AutoDisposeProviderRef<Authentication>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
