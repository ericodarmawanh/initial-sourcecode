import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../data/mock/mock_todo_repository.dart';
import '../../data/repositories/todo_repository.dart';
import '../../data/supabase/supabase_todo_repository.dart';

part 'todo_repository_provider.g.dart';

@riverpod
TodoRepository todoRepository(TodoRepositoryRef ref) =>
    SupabaseTodoRepository();
    // MockTodoRepository();
