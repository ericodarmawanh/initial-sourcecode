import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../entities/todo.dart';
import 'todo_repository_provider.dart';

part 'todos_provider.g.dart';

@riverpod
Stream<List<Todo>> todos(TodosRef ref, String uid) =>
    ref.watch(todoRepositoryProvider).todos(uid);
