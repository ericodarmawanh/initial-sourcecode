import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../entities/user.dart';
import 'authentication_provider.dart';

part 'user_provider.g.dart';

@riverpod
Stream<User?> user(UserRef ref) =>
    ref.watch(authenticationProvider).onUserChanged();
