import 'dart:async';

import 'package:list_to_do/data/mock/mock_todo_repository.dart';
import 'package:list_to_do/data/repositories/authentication.dart';
import 'package:list_to_do/entities/user.dart';

class MockAuthentication implements Authentication {
  static final StreamController<User?> _userStream = StreamController();

  @override
  Future<void> login({required String email, required String password}) async {
    _userStream.sink.add(User(id: '1', email: email));
  }

  @override
  Future<void> logout() async {
    _userStream.sink.add(null);
    MockTodoRepository.resetStream();
  }

  @override
  Stream<User?> onUserChanged() => _userStream.stream;

  @override
  Future<User> register({required String email, required String password}) {
    // TODO: implement register
    throw UnimplementedError();
  }
}
