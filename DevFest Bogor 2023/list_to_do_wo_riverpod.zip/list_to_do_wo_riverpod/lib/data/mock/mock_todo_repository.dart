import 'dart:async';

import 'package:list_to_do/data/repositories/todo_repository.dart';
import 'package:list_to_do/entities/todo.dart';

class MockTodoRepository implements TodoRepository {
  static int autoId = 1;
  static List<Todo> _todos = List.empty(growable: false);
  static StreamController<List<Todo>> _todosStream = StreamController()
    ..add(_todos);

  @override
  Future<void> add(Todo todo) async {
    _todos = [..._todos, todo.copyWith(id: autoId.toString())];
    autoId++;
    _todosStream.sink.add(_todos);
  }

  @override
  Stream<List<Todo>> todos(String uid) => _todosStream.stream;

  @override
  Future<void> update(Todo todo) async {
    _todos = [
      for (final t in _todos)
        if (t.id == todo.id) todo else t
    ];

    _todosStream.sink.add(_todos);
  }

  static void resetStream() {
    _todosStream.close();
    _todos = List.empty(growable: false);
    _todosStream = StreamController()..add(_todos);
  }
}
