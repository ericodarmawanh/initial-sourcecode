import 'package:list_to_do/entities/todo.dart';

abstract final class TodoConverter {
  static Map<String, dynamic> toJson(Todo todo) => {
        'uid': todo.uid,
        'description': todo.description,
        'completed': todo.completed,
      };

  static Todo fromJson(Map<String, dynamic> json) => Todo(
        id: json['id'].toString(),
        uid: json['uid'],
        description: json['description'],
        completed: json['completed'],
      );
}
