import 'package:list_to_do/data/repositories/authentication.dart';
import 'package:list_to_do/entities/user.dart' as models;
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseAuthentication implements Authentication {
  final SupabaseClient supabase;

  SupabaseAuthentication({SupabaseClient? supabase})
      : supabase = supabase ?? Supabase.instance.client;

  @override
  Stream<models.User?> onUserChanged() =>
      supabase.auth.onAuthStateChange.map((event) {
        if (event.event == AuthChangeEvent.signedIn) {
          var currentUser = supabase.auth.currentUser;
          return models.User(
            id: currentUser!.id,
            email: currentUser.email!,
          );
        } else {
          return null;
        }
      });

  @override
  Future<void> login({required String email, required String password}) async {
    try {
      await supabase.auth.signInWithPassword(email: email, password: password);
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<void> logout() async {
    await supabase.auth.signOut();
  }

  @override
  Future<models.User> register(
      {required String email, required String password}) async {
    var response = await supabase.auth.signUp(email: email, password: password);
    return models.User(
      id: response.user!.id,
      email: response.user!.email!,
    );
  }
}
