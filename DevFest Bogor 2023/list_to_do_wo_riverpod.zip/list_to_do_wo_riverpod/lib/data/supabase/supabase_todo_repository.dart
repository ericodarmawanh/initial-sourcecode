import 'package:list_to_do/data/supabase/converter/todo_converter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../entities/todo.dart';
import '../repositories/todo_repository.dart';

class SupabaseTodoRepository implements TodoRepository {
  final SupabaseClient supabase;

  SupabaseTodoRepository({SupabaseClient? supabase})
      : supabase = supabase ?? Supabase.instance.client;

  @override
  Future<void> add(Todo todo) async => await supabase.from('todos').insert(
      TodoConverter.toJson(todo)..removeWhere((key, value) => value == null));

  @override
  Stream<List<Todo>> todos(String uid) => supabase
      .from('todos')
      .stream(primaryKey: ['id'])
      .eq('uid', uid)
      .order('id')
      .map((event) =>
          event.map((json) => TodoConverter.fromJson(json)).toList());

  @override
  Future<void> update(Todo todo) async {
    await supabase
        .from('todos')
        .update(TodoConverter.toJson(todo))
        .eq('id', todo.id);
  }
}
