import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'presentation/pages/login_page.dart';
import 'presentation/pages/main_page.dart';
import 'settings.dart';

const supabaseUrl = 'your supabase url here';
const supabaseKey = 'your supabase key here';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light(useMaterial3: true),
      home: StreamBuilder(
        stream: usedAuthentication.onUserChanged(),
        builder: (context, snapshot) =>
            snapshot.hasData && snapshot.data != null
                ? MainPage(
                    user: snapshot.data!,
                    authentication: usedAuthentication,
                    todoRepository: usedTodoRepository,
                  )
                : LoginPage(usedAuthentication),
      ),
    );
  }
}
