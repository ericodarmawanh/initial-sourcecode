import 'package:flutter/material.dart';

import '../../data/repositories/authentication.dart';
import '../../data/repositories/todo_repository.dart';
import '../../entities/todo.dart';
import '../../entities/user.dart';
import '../widgets/todo_widget.dart';

class MainPage extends StatelessWidget {
  final User user;
  final Authentication authentication;
  final TodoRepository todoRepository;

  MainPage(
      {required this.user,
      required this.authentication,
      required this.todoRepository,
      Key? key})
      : super(key: key);

  final TextEditingController _descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hi, ${user.email}!'),
        backgroundColor: Colors.deepPurple.shade100,
        actions: [
          IconButton(
              onPressed: () {
                authentication.logout();
              },
              icon: const Icon(Icons.logout))
        ],
      ),
      body: StreamBuilder(
          stream: todoRepository.todos(user.id!),
          builder: (context, todosSnapshot) {
            return Center(
              child: Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  Builder(builder: (context) {
                    int count = todosSnapshot.hasData
                        ? todosSnapshot.data!
                            .where((todo) => !todo.completed)
                            .length
                        : 0;
                    return Text(count > 0
                        ? 'You have $count thing(s) to do.'
                        : 'Congrats! You have nothing to do.');
                  }),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width - 130,
                          child: TextField(
                            controller: _descriptionController,
                            decoration: const InputDecoration(
                                labelText: 'Description',
                                border: OutlineInputBorder()),
                          ),
                        ),
                        SizedBox(
                          width: 80,
                          child: ElevatedButton(
                              onPressed: () {
                                todoRepository.add(Todo(
                                    description: _descriptionController.text,
                                    completed: false,
                                    uid: user.id!));

                                _descriptionController.clear();
                              },
                              child: const Text('Add')),
                        )
                      ],
                    ),
                  ),
                  Column(
                    children: todosSnapshot.hasData
                        ? todosSnapshot.data!
                            .map((todo) => TodoWidget(
                                  todo: todo,
                                  width: MediaQuery.of(context).size.width,
                                  onChanged: (value) {
                                    todoRepository.update(
                                        todo.copyWith(completed: value));
                                  },
                                ))
                            .toList()
                        : [],
                  ),
                ],
              ),
            );
          }),
    );
  }
}
