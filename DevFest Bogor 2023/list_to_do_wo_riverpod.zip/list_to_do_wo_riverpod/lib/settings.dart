import 'package:list_to_do/data/repositories/authentication.dart';
import 'package:list_to_do/data/repositories/todo_repository.dart';

import 'data/mock/mock_authentication.dart';
import 'data/mock/mock_todo_repository.dart';
import 'data/supabase/supabase_authentication.dart';
import 'data/supabase/supabase_todo_repository.dart';

// Authentication usedAuthentication = SupabaseAuthentication();
// TodoRepository usedTodoRepository = SupabaseTodoRepository();

Authentication usedAuthentication = MockAuthentication();
TodoRepository usedTodoRepository = MockTodoRepository();
