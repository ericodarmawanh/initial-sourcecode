// import 'package:json/json.dart';
// import 'package:json_annotation/json_annotation.dart';
import 'package:macros_demo/macros/describable.dart';
import 'package:macros_demo/macros/hello.dart';

// part 'person.g.dart';

// @JsonSerializable()
// @JsonCodable()
@Hello()
@Describable()
class Person {
  final String name;
  final int age;

  Person({required this.name, required this.age});

  void sayHello() {
    print('Hello, my name is $name');
  }

  // Map<String, dynamic> toJson() => {
  //       'name': name,
  //       'age': age,
  //     };

  // factory Person.fromJson(Map<String, dynamic> json) {
  //   return Person(
  //     name: json['name'],
  //     age: json['age'],
  //   );
  // }

  // Map<String, dynamic> toJson() => _$PersonToJson(this);
  // factory Person.fromJson(Map<String, dynamic> json) => _$PersonFromJson(json);
}
