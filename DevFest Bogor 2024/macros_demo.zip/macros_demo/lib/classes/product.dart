import 'package:macros_demo/macros/describable.dart';
import 'package:macros_demo/macros/hello.dart';

@Hello()
@Describable()
class Product {
  final String name;
  final String description;
  final double price;

  Product({required this.name, required this.description, required this.price});

  void showProduct() {
    print('Product: $name');
    print('Description: $description');
    print('Price: $price');
  }

  void buy() {
    print('Buying $name');
  }
}
