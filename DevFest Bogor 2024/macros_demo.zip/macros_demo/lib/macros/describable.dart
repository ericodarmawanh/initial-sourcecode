import 'dart:async';
import 'package:macros/macros.dart';

// ClassDeclarationsMacro is an interface for Macros that can be applied to any class
// Find the full list of macro interfaces at https://github.com/dart-lang/sdk/blob/main/pkg/_macros/lib/src/api/macros.dart
macro class Describable implements ClassDeclarationsMacro {
  // The constructor corresponds to the annotation for applying the macro to a declaration..
  const Describable();

  // The method that will be called when the macro is applied to a class declaration
  // ClassDeclaration contains information about the class the macro is applied to.
  // MemberDeclarationBuilder is the API used to contribute new members to a type.
  @override
  FutureOr<void> buildDeclarationsForClass(ClassDeclaration clazz, MemberDeclarationBuilder builder,) async {
    List<FieldDeclaration> fields = await builder.fieldsOf(clazz);
    List<MethodDeclaration> methods = await builder.methodsOf(clazz);

    // Method declareInType is used to add new members to the class.
    builder.declareInType(DeclarationCode.fromParts([
      """
      @override
      String toString() {
        return '${clazz.identifier.name}\\n===\\nFields:\\n""",
        fields.map((f) => '- ${f.identifier.name}: \$${f.identifier.name}',).join('\\n'),
      if(methods.isNotEmpty)  """\\nMethods:\\n""",
      if(methods.isNotEmpty) methods.map((m) => '- ${m.identifier.name}',).join('\\n'),
      """';
      }"""
    ]));
  }
}