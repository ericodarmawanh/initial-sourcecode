import 'dart:async';
import 'package:macros/macros.dart';

// ClassDeclarationsMacro is an interface for Macros that can be applied to any class
// Find the full list of macro interfaces at https://github.com/dart-lang/sdk/blob/main/pkg/_macros/lib/src/api/macros.dart
macro class Hello implements ClassDeclarationsMacro {
  // The constructor corresponds to the annotation for applying the macro to a declaration..
  const Hello();

  // The method that will be called when the macro is applied to a class declaration
  // ClassDeclaration contains information about the class the macro is applied to.
  @override
  FutureOr<void> buildDeclarationsForClass(ClassDeclaration clazz, MemberDeclarationBuilder builder,) async {
    // Method declareInType is used to add new members to the class.
    builder.declareInType(DeclarationCode.fromParts([
      """
      String hello() {
        return "Hello.. I'm ${clazz.identifier.name}";
      }"""
    ]));
  }
}