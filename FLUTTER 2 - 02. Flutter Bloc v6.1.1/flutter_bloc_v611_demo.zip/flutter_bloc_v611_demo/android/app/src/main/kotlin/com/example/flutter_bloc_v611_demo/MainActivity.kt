package com.example.flutter_bloc_v611_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
