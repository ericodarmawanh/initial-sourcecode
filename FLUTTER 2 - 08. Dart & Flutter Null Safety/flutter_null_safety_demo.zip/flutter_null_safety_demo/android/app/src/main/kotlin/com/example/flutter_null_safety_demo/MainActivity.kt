package com.example.flutter_null_safety_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
