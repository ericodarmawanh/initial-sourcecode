import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  TextEditingController controller = TextEditingController();
  MyNumber myNumber = MyNumber();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter - null safety | Demo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(
                  hintText: 'Insert a number', labelText: 'Number'),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 20),
              width: double.infinity,
              child: RaisedButton(
                  child: Text('CALCULATE'),
                  onPressed: () {
                    setState(() {
                      myNumber.number = int.tryParse(controller.text);
                    });
                  }),
            ),
            Text('RESULT: ${myNumber.number}'),
          ],
        ),
      ),
    );
  }
}

class MyNumber {
  int number;

  int multiplyByTwo() => number * 2;
}
