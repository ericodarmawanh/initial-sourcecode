package com.example.flutter_bloc_ver73_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
