import 'package:flutter/material.dart';

class PreviewPage extends StatelessWidget {
  const PreviewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Preview Page'),
        ),
        body: Center(
          child: ElevatedButton(
              onPressed: () {}, child: const Text('An awesome button')),
        ));
  }
}
