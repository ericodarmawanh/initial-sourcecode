package com.example.dio_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
