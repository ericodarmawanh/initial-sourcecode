class Person {
  int id;
  String name;
  String email;

  Person({required this.id, required this.name, required this.email});
}
