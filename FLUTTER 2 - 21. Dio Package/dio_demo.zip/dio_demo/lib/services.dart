import 'person.dart';

abstract class Services {
  static Future<Person?> getById(int id) async {}

  static Future<Person?> createUser(
      String firstName, String lastName, String email) async {}
}
