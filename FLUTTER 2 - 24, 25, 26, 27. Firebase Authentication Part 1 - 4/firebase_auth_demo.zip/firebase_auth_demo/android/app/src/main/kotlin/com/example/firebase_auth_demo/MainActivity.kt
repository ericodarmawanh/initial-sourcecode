package com.ericodh.firebase_auth_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
