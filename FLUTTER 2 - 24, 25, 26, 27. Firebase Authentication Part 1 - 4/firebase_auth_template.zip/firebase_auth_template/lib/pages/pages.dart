import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

part 'anon_signin_page.dart';
part 'email_signin_page.dart';
part 'google_sign_in_page.dart';
part 'phone_signin_page.dart';