package com.example.go_router_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
