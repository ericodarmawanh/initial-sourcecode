package com.example.stateful_builder_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
