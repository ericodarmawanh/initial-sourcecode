import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:stateful_builder_demo/public_methods.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int number = 0;

  @override
  Widget build(BuildContext context) {
    log('==== BUILDING PAGE ====');
    return Scaffold(
      appBar: AppBar(
        title: makingText('Stateful MainPage'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            makingText('Current Number'),
            makingText(number.toString(), fontSize: 30),
            makingSpace(20),
            makingButton('Increment', onPressed: () {
              setState(() {
                number++;
              });
            })
          ],
        ),
      ),
    );
  }
}
