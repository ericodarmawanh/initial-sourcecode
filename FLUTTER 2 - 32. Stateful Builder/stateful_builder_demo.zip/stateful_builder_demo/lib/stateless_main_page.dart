import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:stateful_builder_demo/public_methods.dart';

class StatelessMainPage extends StatelessWidget {
  const StatelessMainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    log('==== BUILDING PAGE ====');
    return Scaffold(
      appBar: AppBar(
        title: makingText('Stateful MainPage'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            makingText('Current Number'),
            makingText('0', fontSize: 30),
            makingSpace(20),
            makingButton('Increment', onPressed: () {})
          ],
        ),
      ),
    );
  }
}
