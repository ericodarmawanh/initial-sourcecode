package com.example.union_freezed_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
