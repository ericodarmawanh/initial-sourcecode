package com.example.riverpod_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
