package com.example.riverpod_counter_app_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
