package com.example.riverpod_person_provider_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
