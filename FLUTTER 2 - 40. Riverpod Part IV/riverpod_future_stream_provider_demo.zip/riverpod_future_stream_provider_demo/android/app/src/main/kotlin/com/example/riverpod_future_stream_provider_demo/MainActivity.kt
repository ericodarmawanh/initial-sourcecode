package com.example.riverpod_future_stream_provider_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
