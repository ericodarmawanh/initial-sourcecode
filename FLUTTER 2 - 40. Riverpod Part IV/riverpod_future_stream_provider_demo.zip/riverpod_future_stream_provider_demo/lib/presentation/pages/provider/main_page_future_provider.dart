import 'package:flutter/material.dart';

class MainPageFutureProvider extends StatelessWidget {
  const MainPageFutureProvider({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Future Provider'),
      ),
      body: Center(),
    );
  }
}
