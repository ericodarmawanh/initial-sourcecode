package com.example.riverpod_modifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
