# objectbox_crud

A new Flutter project.
