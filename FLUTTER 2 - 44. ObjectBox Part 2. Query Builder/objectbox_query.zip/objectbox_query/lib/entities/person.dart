import 'package:objectbox/objectbox.dart';

@Entity()
class Person {}
