package com.example.objectbox_relations

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
