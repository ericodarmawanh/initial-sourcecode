import 'entities/mobile_phone.dart';
import 'entities/person.dart';
import 'objectbox.g.dart';

// name: the new person's name
int putNewPerson({required Box<Person> personBox, required String name}) {
  throw UnimplementedError();
}

// name: the new phone's name
// owner: the person who owns the phone
void putNewPhone(
    {required String mobilePhoneName,
    required Person owner,
    required Box<MobilePhone> mobilePhoneBox}) {
  throw UnimplementedError();
}

// mobilePhone: the phone to be converted to a string
String convertMobilePhoneToString(MobilePhone mobilePhone) {
  // ignore: unnecessary_string_interpolations
  return '${mobilePhone.name}';
}

// person: the person who owns the phone whose name to be gotten
List<String> getPersonMobilePhoneNames(Person person) {
  return List.empty();
}

// person: the person who owns the phone to be removed
void removeFirstPhone(
    {required Person person,
    required Box<Person> personBox,
    required Box<MobilePhone> mobilePhoneBox}) {
  throw UnimplementedError();
}

// person: the person to be removed
void removePerson(
    {required Box<Person> personBox,
    required Box<MobilePhone> mobilePhoneBox,
    required Person person}) {
  throw UnimplementedError();
}
