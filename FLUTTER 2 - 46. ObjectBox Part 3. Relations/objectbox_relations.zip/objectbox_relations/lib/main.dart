import 'package:flutter/material.dart';

import 'entities/objectbox.dart';
import 'objectbox.g.dart';
import 'pages/main_page.dart';

late Store store;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  store = (await ObjectBox.create()).store;

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light(useMaterial3: true),
      home: const MainPage(),
    );
  }
}
