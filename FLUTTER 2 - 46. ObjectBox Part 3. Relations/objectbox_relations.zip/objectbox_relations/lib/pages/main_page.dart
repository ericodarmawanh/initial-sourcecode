import 'package:flutter/material.dart';

import '../code_for_explanation.dart';
import '../entities/mobile_phone.dart';
import '../entities/person.dart';
import '../main.dart';
import '../objectbox.g.dart';
import '../widgets/mobile_phone_viewer.dart';
import '../widgets/person_dropdown_button.dart';
import '../widgets/selected_person_mobile_phones.dart';
import '../widgets/subtitle_text.dart';
import '../widgets/title_text.dart';
import '../widgets/vertical_space.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final Box<Person> personBox = store.box<Person>();
  final Box<MobilePhone> mobilePhoneBox = store.box<MobilePhone>();

  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneNameController = TextEditingController();

  Person? selectedPerson;

  late List<Person> persons;

  @override
  void initState() {
    super.initState();

    persons = personBox.getAll();

    if (persons.isNotEmpty) {
      selectedPerson = persons.first;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ObjectBox Relations'),
        elevation: 12,
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                VerticalSpace.h20(),
                const TitleText('Persons'),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(hintText: 'Name'),
                ),
                VerticalSpace.h20(),
                Center(
                  child: ElevatedButton(
                      onPressed: createPersonButtonPressed,
                      child: const Text('Create new Person')),
                ),
                VerticalSpace.h20(),
                const SubtitleText('Selected person:'),
                PersonDropdownButton(
                  persons: persons,
                  selectedPerson: selectedPerson,
                  onChanged: (value) {
                    setState(() {
                      selectedPerson = value;
                    });
                  },
                ),
                Center(
                  child: ElevatedButton(
                      onPressed: removePersonButtonPressed,
                      child: Text(
                          "Remove ${selectedPerson != null ? selectedPerson!.name : 'Selected person'}")),
                ),
                VerticalSpace.h40(),
                const TitleText('Mobile Phones'),
                TextField(
                  controller: phoneNameController,
                  decoration: const InputDecoration(hintText: "Phone's name"),
                ),
                VerticalSpace.h20(),
                Center(
                  child: ElevatedButton(
                      onPressed: addPhoneButtonPressed,
                      child: const Text('Add new Phone')),
                ),
                VerticalSpace.h20(),
                const SubtitleText('All mobile phone(s):'),
                MobilePhoneViewer(mobilePhoneBox),
                SubtitleText(
                    "${selectedPerson != null ? selectedPerson!.name : 'Selected person'}'s mobile phone(s):"),
                SelectedPersonMobilePhones(selectedPerson),
                Center(
                  child: ElevatedButton(
                      onPressed: removeFirstMobilePhoneButtonPressed,
                      child: Text(
                          "Remove ${selectedPerson != null ? selectedPerson!.name : 'Selected person'}'s first phone:")),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Person addnewPerson(String name) {
    int id = putNewPerson(name: name, personBox: personBox);

    persons = personBox.getAll();

    return persons.where((p) => p.id == id).first;
  }

  void refreshPersons() {
    persons = personBox.getAll();

    if (selectedPerson != null) {
      selectedPerson = persons.where((p) => p.id == selectedPerson!.id).first;
    }
  }

  createPersonButtonPressed() {
    setState(() {
      Person person = addnewPerson(nameController.text);

      selectedPerson = person;

      nameController.clear();
    });
  }

  removePersonButtonPressed() {
    setState(() {
      if (selectedPerson != null) {
        removePerson(
            personBox: personBox,
            mobilePhoneBox: mobilePhoneBox,
            person: selectedPerson!);
        selectedPerson = null;
        refreshPersons();
      }
    });
  }

  addPhoneButtonPressed() {
    setState(() {
      if (selectedPerson != null) {
        putNewPhone(
            mobilePhoneName: phoneNameController.text,
            owner: selectedPerson!,
            mobilePhoneBox: mobilePhoneBox);

        phoneNameController.clear();

        refreshPersons();
      }
    });
  }

  void removeFirstMobilePhoneButtonPressed() {
    if (selectedPerson != null) {
      setState(() {
        removeFirstPhone(
            person: selectedPerson!,
            mobilePhoneBox: mobilePhoneBox,
            personBox: personBox);

        refreshPersons();
      });
    }
  }
}
