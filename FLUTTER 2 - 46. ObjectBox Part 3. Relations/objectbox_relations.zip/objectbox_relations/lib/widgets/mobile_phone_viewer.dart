import 'package:flutter/material.dart';
import 'package:objectbox_relations/code_for_explanation.dart';
import 'package:objectbox_relations/entities/mobile_phone.dart';
import 'package:objectbox_relations/objectbox.g.dart';

class MobilePhoneViewer extends StatelessWidget {
  final Box<MobilePhone> mobilePhoneBox;

  const MobilePhoneViewer(this.mobilePhoneBox, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10, bottom: 20),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
      ),
      child: Column(
        children: mobilePhoneBox
            .getAll()
            .map((e) => Text(convertMobilePhoneToString(e)))
            .toList(),
      ),
    );
  }
}
