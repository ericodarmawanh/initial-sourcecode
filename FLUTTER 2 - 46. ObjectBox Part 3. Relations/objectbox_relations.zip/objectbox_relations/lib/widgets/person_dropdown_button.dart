import 'package:flutter/material.dart';

import '../entities/person.dart';

class PersonDropdownButton extends StatelessWidget {
  final List<Person> persons;
  final Person? selectedPerson;
  final void Function(Person?)? onChanged;

  const PersonDropdownButton(
      {super.key, required this.persons, this.selectedPerson, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: DropdownButton(
        isExpanded: true,
        alignment: Alignment.center,
        value: selectedPerson,
        items: persons
            .map((e) => DropdownMenuItem(
                  value: e,
                  child: Text(e.name),
                ))
            .toList(),
        onChanged: onChanged,
      ),
    );
  }
}
