import 'package:flutter/material.dart';

class SubtitleText extends StatelessWidget {
  final String subtitle;

  const SubtitleText(this.subtitle, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      subtitle,
      style: const TextStyle(fontWeight: FontWeight.w500),
    );
  }
}
