import 'package:flutter/material.dart';

class VerticalSpace extends StatelessWidget {
  final double? height;

  const VerticalSpace._(this.height, {super.key});

  factory VerticalSpace.h20() => const VerticalSpace._(20);
  factory VerticalSpace.h40() => const VerticalSpace._(40);

  @override
  Widget build(BuildContext context) {
    return SizedBox(height: height);
  }
}
