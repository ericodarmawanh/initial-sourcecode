package com.example.objectbox_sync_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
