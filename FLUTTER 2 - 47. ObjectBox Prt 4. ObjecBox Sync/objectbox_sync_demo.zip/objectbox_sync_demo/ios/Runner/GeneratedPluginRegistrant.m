//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<objectbox_sync_flutter_libs/ObjectboxSyncFlutterLibsPlugin.h>)
#import <objectbox_sync_flutter_libs/ObjectboxSyncFlutterLibsPlugin.h>
#else
@import objectbox_sync_flutter_libs;
#endif

#if __has_include(<path_provider_foundation/PathProviderPlugin.h>)
#import <path_provider_foundation/PathProviderPlugin.h>
#else
@import path_provider_foundation;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ObjectboxSyncFlutterLibsPlugin registerWithRegistrar:[registry registrarForPlugin:@"ObjectboxSyncFlutterLibsPlugin"]];
  [PathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"PathProviderPlugin"]];
}

@end
