import 'package:flutter/material.dart';
import 'package:random_name_generator/random_name_generator.dart';
import 'main.dart';

import 'objectbox.g.dart';
import 'person.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final Box<Person> personBox = store.box<Person>();
  final RandomNames randomNames = RandomNames(Zone.us);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ObjectBox Sync Demo'),
        elevation: 12,
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                personBox.put(Person(name: randomNames.fullName()));
              },
              child: const Text('Add Random Person'),
            ),
            const SizedBox(height: 20),
            Column(
              children: const [],
            )
          ],
        ),
      ),
    );
  }
}
