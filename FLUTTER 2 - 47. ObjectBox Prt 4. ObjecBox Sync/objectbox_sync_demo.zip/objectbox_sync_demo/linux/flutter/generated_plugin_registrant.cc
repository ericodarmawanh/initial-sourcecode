//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"

#include <objectbox_sync_flutter_libs/objectbox_sync_flutter_libs_plugin.h>

void fl_register_plugins(FlPluginRegistry* registry) {
  g_autoptr(FlPluginRegistrar) objectbox_sync_flutter_libs_registrar =
      fl_plugin_registry_get_registrar_for_plugin(registry, "ObjectboxSyncFlutterLibsPlugin");
  objectbox_sync_flutter_libs_plugin_register_with_registrar(objectbox_sync_flutter_libs_registrar);
}
