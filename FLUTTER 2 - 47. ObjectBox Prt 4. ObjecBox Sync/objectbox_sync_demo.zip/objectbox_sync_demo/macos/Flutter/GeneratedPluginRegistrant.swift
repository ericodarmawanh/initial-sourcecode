//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import objectbox_sync_flutter_libs
import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ObjectboxSyncFlutterLibsPlugin.register(with: registry.registrar(forPlugin: "ObjectboxSyncFlutterLibsPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
