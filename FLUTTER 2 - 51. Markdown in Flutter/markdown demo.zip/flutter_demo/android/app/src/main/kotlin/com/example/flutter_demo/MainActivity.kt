package com.example.flutter_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
