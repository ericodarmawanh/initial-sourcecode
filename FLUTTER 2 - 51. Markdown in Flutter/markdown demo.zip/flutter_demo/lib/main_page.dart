import 'package:flutter/material.dart';
import 'package:flutter_demo/markdown_text.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.amber.shade100,
          title: const Text('Markdown Demo'),
        ),
        body: Text(markdownText));
  }
}
