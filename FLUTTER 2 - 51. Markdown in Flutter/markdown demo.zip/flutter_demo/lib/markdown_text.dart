String markdownText = '''
# Markdown Demo 😀 :wink: :cry: :laughing: :yum:
---
# h1 Heading
## h2 Heading
### h3 Heading
#### h4 Heading
##### h5 Heading
###### h6 Heading
---
**Bold**

*Italic*

***Bold and Italic***

~~Strikethrough~~

[This is a Link](https://github.com)

![This is an Image](https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png)

> This is a quote. - by someone

This is an inline code example: `print('Hello, World!');`

    // Indented code
    void main() {
      print('Hello, World!');
    }

Ordered List:
1. Ordered List Item 1
2. Ordered List Item 2
3. Ordered List Item 3

Unordered List:
- Unordered List Item 1
- Unordered List Item 2
- Unordered List Item 3

| Option | Description |
| ------ | ----------- |
| data   | path to data files to supply the data that will be passed into templates. |
| engine | engine to be used for processing templates. Handlebars is the default. |
| ext    | extension to be used for dest files. |
''';
