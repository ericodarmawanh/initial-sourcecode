package com.example.flutter_45

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
