package com.example.supercharged_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
