package com.example.getx_navigation_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
