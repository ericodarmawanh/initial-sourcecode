package com.example.replay_bloc_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
