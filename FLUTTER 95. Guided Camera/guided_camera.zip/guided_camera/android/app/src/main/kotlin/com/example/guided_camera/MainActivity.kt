package com.example.guided_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
