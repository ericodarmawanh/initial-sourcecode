package com.example.state_management_webinar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
