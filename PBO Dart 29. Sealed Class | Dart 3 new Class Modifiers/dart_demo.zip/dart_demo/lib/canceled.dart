import 'package:dart_demo/transaction_status.dart';

class Canceled extends TransactionStatus {
  final String reason;

  Canceled({required super.transactionId, required this.reason});
}
