import 'package:dart_demo/transaction_status.dart';

class Pending extends TransactionStatus {
  Pending({required super.transactionId});
}
