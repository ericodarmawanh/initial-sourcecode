import 'package:dart_demo/transaction_status.dart';

class Success extends TransactionStatus {
  Success({required super.transactionId});
}
