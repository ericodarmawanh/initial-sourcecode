abstract class TransactionStatus {
  final String transactionId;

  TransactionStatus({required this.transactionId});
}
