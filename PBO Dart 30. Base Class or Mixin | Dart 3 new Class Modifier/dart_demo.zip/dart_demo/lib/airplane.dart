import 'package:dart_demo/fly_mixin.dart';
import 'package:dart_demo/vehicle.dart';

class AirPlane implements Vehicle, FlyMixin {
  @override
  void fly() {
    print('I am flying with airplane speed');
  }

  @override
  String get name => 'I am an airplane';
}
