import 'package:dart_demo/vehicle.dart';

class Car implements Vehicle {
  @override
  String get name => 'I am a car';
}
