mixin FlyMixin {
  void fly() {
    print('I am flying');
  }
}
