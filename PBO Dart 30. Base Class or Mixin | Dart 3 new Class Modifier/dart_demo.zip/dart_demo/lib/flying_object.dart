mixin class FlyingObject {
  void fly() {
    print('I am flying');
  }
}
