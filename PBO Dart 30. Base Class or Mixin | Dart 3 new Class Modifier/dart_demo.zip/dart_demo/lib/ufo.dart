import 'package:dart_demo/flying_object.dart';

class Ufo implements FlyingObject {
  @override
  void fly() {
    print('I am flying with UFO speed');
  }
}
