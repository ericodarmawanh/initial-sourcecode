abstract class Vehicle {
  final String name;

  Vehicle({required this.name});
}
