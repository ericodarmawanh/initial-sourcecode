package com.example.riverpod_generator_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
