import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'providers/number_provider_manually.dart';
import 'providers/simple_string_provider_manually.dart';
import 'providers/user_provider_manually.dart';

void main() {
  runApp(const ProviderScope(child: MainApp()));
}

class MainApp extends ConsumerWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(ref.watch(simpleStringProviderManually)),
              const SizedBox(height: 10),
              Text(ref.watch(userProviderManually('Jennie Kim')).when(
                    data: (data) => data.name,
                    error: (error, stackTrace) => 'Error',
                    loading: () => 'Loading',
                  )),
              const SizedBox(height: 10),
              Text(ref.watch(numberProviderManually).when(
                    data: (data) => data.toString(),
                    error: (error, stackTrace) => 'Error',
                    loading: () => 'Loading',
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
