import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'number_repository_provider_manually.dart';

final numberProviderManually = StreamProvider<int>(
    (ref) => ref.watch(numberRepositoryProviderManually).getStreamOfNumbers());
