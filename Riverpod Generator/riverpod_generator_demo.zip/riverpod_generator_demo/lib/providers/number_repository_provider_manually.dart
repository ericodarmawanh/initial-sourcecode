import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repositories/number_repository.dart';

final numberRepositoryProviderManually =
    Provider<NumberRepository>((ref) => NumberRepository());
