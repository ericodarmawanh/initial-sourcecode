import 'package:flutter_riverpod/flutter_riverpod.dart';

final simpleStringProviderManually =
    Provider<String>((ref) => 'A String Provider');
