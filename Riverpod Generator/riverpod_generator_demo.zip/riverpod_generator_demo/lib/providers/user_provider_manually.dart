import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../entities/user.dart';
import 'user_repository_provider_manually.dart';

final userProviderManually = FutureProvider.family<User, String>(
    (ref, username) =>
        ref.watch(userRepositoryProviderManually).createUser(username));
