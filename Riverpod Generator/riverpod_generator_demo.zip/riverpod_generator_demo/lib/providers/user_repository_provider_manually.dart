import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repositories/user_repository.dart';

final userRepositoryProviderManually =
    Provider<UserRepository>((ref) => UserRepository());
