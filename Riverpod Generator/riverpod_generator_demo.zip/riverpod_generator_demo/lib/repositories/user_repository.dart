import '../entities/user.dart';

class UserRepository {
  Future<User> createUser(String name) async {
    await Future.delayed(const Duration(seconds: 1));
    return User(name);
  }
}
